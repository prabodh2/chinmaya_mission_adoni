import Media from '../models/Media.js';
import Banner from '../models/Banner.js';
import Activity from '../models/Activity.js';
import HomePage from '../models/HomePage.js';
import PageContent from '../models/PageContent.js';
import Footer from '../models/Footer.js';
import { uploadToR2, deleteFromR2 } from '../config/r2.js';
import { seedInitialData } from '../utils/seedData.js';

// @desc    Get paginated media items with search & filtering
// @route   GET /api/media
// @access  Private/Admin
export const getMediaList = async (req, res) => {
  try {
    const totalMedia = await Media.countDocuments();
    if (totalMedia === 0) {
      await seedInitialData();
    }
    const {
      search,
      category,
      pageName,
      status,
      page = 1,
      limit = 24,
      sortBy = 'createdAt',
      order = 'desc',
    } = req.query;

    const query = {};

    if (status && ['ACTIVE', 'INACTIVE'].includes(status.toUpperCase())) {
      query.status = status.toUpperCase();
    }

    if (category && category !== 'ALL') {
      query.category = category;
    }

    if (pageName && pageName !== 'ALL') {
      query.page = pageName;
    }

    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { fileName: searchRegex },
        { title: searchRegex },
        { description: searchRegex },
        { altText: searchRegex },
        { tags: searchRegex },
        { page: searchRegex },
        { section: searchRegex },
      ];
    }

    const sortOrder = order === 'asc' ? 1 : -1;
    const sortObj = { [sortBy]: sortOrder };

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 24;
    const skip = (pageNum - 1) * limitNum;

    const [items, total] = await Promise.all([
      Media.find(query).sort(sortObj).skip(skip).limit(limitNum).lean(),
      Media.countDocuments(query),
    ]);

    res.json({
      success: true,
      data: {
        items,
        pagination: {
          total,
          page: pageNum,
          pages: Math.ceil(total / limitNum) || 1,
          limit: limitNum,
        },
      },
    });
  } catch (err) {
    console.error('[Get Media List Error]:', err.message);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve media library items',
      errorCode: 'MEDIA_FETCH_ERROR',
    });
  }
};

// @desc    Get single media item by ID
// @route   GET /api/media/:id
// @access  Private/Admin
export const getMediaById = async (req, res) => {
  try {
    const media = await Media.findById(req.params.id);
    if (!media) {
      return res.status(404).json({
        success: false,
        message: 'Media asset not found',
        errorCode: 'MEDIA_NOT_FOUND',
      });
    }
    res.json({ success: true, data: media });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc    Upload new image asset & create media record
// @route   POST /api/media/upload
// @access  Private/Admin
export const uploadMedia = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file uploaded',
        errorCode: 'FILE_MISSING',
      });
    }

    const {
      title = '',
      description = '',
      caption = '',
      altText = 'Anti-Drug Movement Marathon 2026 Asset',
      category = 'Other',
      page = 'General',
      section = 'General',
      tags = '',
      status = 'ACTIVE',
      displayOrder = 0,
      width = 0,
      height = 0,
    } = req.body;

    const folder = `chinmaya/media/${category.toLowerCase().replace(/\s+/g, '_')}`;
    const result = await uploadToR2(req.file.buffer, folder, req.file.mimetype, req.file.originalname);

    const parsedTags = typeof tags === 'string'
      ? tags.split(',').map((t) => t.trim()).filter(Boolean)
      : Array.isArray(tags) ? tags : [];

    const originalName = req.file.originalname || 'uploaded_image';
    const cleanFileName = originalName.replace(/[^a-zA-Z0-9_.-]/g, '_');

    const media = new Media({
      fileName: cleanFileName,
      originalFileName: originalName,
      title: title.trim() || cleanFileName,
      description: description.trim(),
      caption: caption.trim(),
      altText: altText.trim() || 'Anti-Drug Movement Marathon 2026 Asset',
      url: result.url,
      thumbnailUrl: result.url,
      publicId: result.public_id,
      mimeType: req.file.mimetype,
      fileSize: req.file.size || req.file.buffer.length,
      width: Number(width) || 0,
      height: Number(height) || 0,
      category,
      page,
      section,
      tags: parsedTags,
      status: ['ACTIVE', 'INACTIVE'].includes(status.toUpperCase()) ? status.toUpperCase() : 'ACTIVE',
      displayOrder: Number(displayOrder) || 0,
      usedIn: [{ page, section, component: 'CMS' }],
      createdBy: req.user?._id,
      updatedBy: req.user?._id,
    });

    await media.save();

    // Immediately sync new image across all relevant CMS collections
    await syncMediaImageToCollections(media);

    res.status(201).json({
      success: true,
      message: 'Image uploaded and added to media library successfully',
      data: media,
    });
  } catch (err) {
    console.error('[Upload Media Error]:', err.message);
    res.status(500).json({
      success: false,
      message: err.message || 'Image upload failed',
      errorCode: 'UPLOAD_ERROR',
    });
  }
};

// Helper function to sync media URL & title changes across all CMS collections
export const syncMediaImageToCollections = async (mediaItem, oldUrl) => {
  try {
    if (!mediaItem || !mediaItem.url) return;

    const newUrl = mediaItem.url;
    const publicId = mediaItem.publicId;

    // 1. Sync to Banners (Vertical Poster Carousel)
    if (
      mediaItem.section === 'Vertical Poster Carousel' ||
      (mediaItem.category === 'Banner' && mediaItem.page === 'Home')
    ) {
      const bannerQuery = {
        $or: [
          { publicId: publicId },
          { title: mediaItem.title },
        ],
      };
      if (oldUrl) bannerQuery.$or.push({ imageUrl: oldUrl });
      const existing = await Banner.findOne(bannerQuery);
      if (existing) {
        await Banner.updateOne(
          { _id: existing._id },
          { $set: { imageUrl: newUrl, active: mediaItem.status === 'ACTIVE', updatedAt: new Date() } }
        );
      } else {
        await Banner.create({
          title: mediaItem.title,
          imageUrl: newUrl,
          publicId: publicId,
          bannerType: 'VERTICAL',
          order: mediaItem.displayOrder || 1,
          active: mediaItem.status === 'ACTIVE',
        });
      }
    }

    // 1b. Sync Horizontal Banner (Hero)
    if (
      mediaItem.section === 'Hero Banner' ||
      (mediaItem.category === 'Banner' && (mediaItem.title || '').toLowerCase().includes('hero'))
    ) {
      await Banner.updateMany({ bannerType: 'HORIZONTAL' }, { $set: { imageUrl: newUrl, active: true, updatedAt: new Date() } });
      const homeConfig = await HomePage.findOne();
      if (homeConfig && Array.isArray(homeConfig.sections)) {
        homeConfig.sections.forEach((sec) => {
          if (sec.type === 'hero') sec.imageUrl = newUrl;
        });
        await homeConfig.save();
      }
    }

    // 2. Sync to Activities
    if (mediaItem.category === 'Activities' || mediaItem.page === 'Activities') {
      const activityQuery = {
        $or: [
          { publicId: publicId },
          { title: mediaItem.title },
        ],
      };
      if (oldUrl) activityQuery.$or.push({ imageUrl: oldUrl });
      const existing = await Activity.findOne(activityQuery);
      if (existing) {
        await Activity.updateOne(
          { _id: existing._id },
          {
            $set: {
              imageUrl: newUrl,
              description: mediaItem.description || existing.description,
              active: mediaItem.status === 'ACTIVE',
              updatedAt: new Date(),
            },
          }
        );
      } else {
        await Activity.create({
          title: mediaItem.title,
          category: mediaItem.section || 'Activity',
          description: mediaItem.description || mediaItem.caption || mediaItem.title,
          imageUrl: newUrl,
          publicId: publicId,
          order: mediaItem.displayOrder || 0,
          active: mediaItem.status === 'ACTIVE',
        });
      }
    }

    // 3. Sync to HomePage sections & disabled maintenance image
    const homeConfig = await HomePage.findOne();
    if (homeConfig) {
      let updatedHome = false;
      if (oldUrl && homeConfig.disabledImage === oldUrl) {
        homeConfig.disabledImage = newUrl;
        updatedHome = true;
      }
      if (Array.isArray(homeConfig.sections)) {
        homeConfig.sections.forEach((sec) => {
          if (
            (oldUrl && sec.imageUrl === oldUrl) ||
            (sec.title && sec.title.toLowerCase() === (mediaItem.title || '').toLowerCase()) ||
            (mediaItem.section === 'Hero Banner' && sec.type === 'hero')
          ) {
            sec.imageUrl = newUrl;
            updatedHome = true;
          }
        });
      }
      if (updatedHome) {
        await homeConfig.save();
      }
    }

    // 4. Sync to PageContent (e.g. About Page)
    const aboutContent = await PageContent.findOne({ sectionKey: 'about_page' });
    if (aboutContent && aboutContent.content) {
      let updatedAbout = false;
      const jsonStr = JSON.stringify(aboutContent.content);
      if (oldUrl && jsonStr.includes(oldUrl)) {
        const replacedStr = jsonStr.replaceAll(oldUrl, newUrl);
        aboutContent.content = JSON.parse(replacedStr);
        updatedAbout = true;
      } else {
        const c = aboutContent.content;
        if (c.hero && (mediaItem.section === 'Hero Header' || (mediaItem.title || '').toLowerCase().includes('hero'))) {
          c.hero.imageUrl = newUrl;
          updatedAbout = true;
        }
        if (c.chykSection && (mediaItem.category === 'About' || mediaItem.page === 'About') && (mediaItem.title || '').toLowerCase().includes('chyk')) {
          c.chykSection.imageUrl = newUrl;
          updatedAbout = true;
        }
        if (c.ourActivities && Array.isArray(c.ourActivities.cards)) {
          c.ourActivities.cards.forEach((card) => {
            if (card.title && mediaItem.title && (card.title.toLowerCase().includes(mediaItem.title.toLowerCase()) || mediaItem.title.toLowerCase().includes(card.title.toLowerCase()))) {
              card.imageUrl = newUrl;
              updatedAbout = true;
            }
          });
        }
      }
      if (updatedAbout) {
        await aboutContent.save();
      }
    }

    // 5. Sync to Footer
    const footerConfig = await Footer.findOne();
    if (footerConfig && oldUrl && footerConfig.logoUrl === oldUrl) {
      footerConfig.logoUrl = newUrl;
      await footerConfig.save();
    }
  } catch (err) {
    console.error('[Sync Media Image Error]:', err.message);
  }
};

// @desc    Update media asset & metadata (With optional image file replacement)
// @route   PUT /api/media/:id
// @access  Private/Admin
export const updateMedia = async (req, res) => {
  try {
    const media = await Media.findById(req.params.id);
    if (!media) {
      return res.status(404).json({
        success: false,
        message: 'Media item not found',
        errorCode: 'MEDIA_NOT_FOUND',
      });
    }

    const oldUrl = media.url;

    const {
      title,
      description,
      caption,
      altText,
      category,
      page,
      section,
      tags,
      status,
      displayOrder,
      usedIn,
    } = req.body;

    // Check if a new image file is uploaded with the edit request
    if (req.file) {
      const catName = category || media.category || 'other';
      const folder = `chinmaya/media/${catName.toLowerCase().replace(/\s+/g, '_')}`;
      const result = await uploadToR2(req.file.buffer, folder, req.file.mimetype, req.file.originalname);

      media.url = result.url;
      media.thumbnailUrl = result.url;
      media.publicId = result.public_id;
      media.mimeType = req.file.mimetype;
      media.fileSize = req.file.size || req.file.buffer.length;
      if (req.file.originalname) {
        media.originalFileName = req.file.originalname;
        if (!title && !media.title) {
          media.fileName = req.file.originalname.replace(/[^a-zA-Z0-9_.-]/g, '_');
        }
      }
    }

    if (title !== undefined) media.title = title.trim();
    if (description !== undefined) media.description = description.trim();
    if (caption !== undefined) media.caption = caption.trim();
    if (altText !== undefined) media.altText = altText.trim();
    if (category !== undefined) media.category = category;
    if (page !== undefined) media.page = page;
    if (section !== undefined) media.section = section;
    if (displayOrder !== undefined) media.displayOrder = Number(displayOrder) || 0;
    if (status && ['ACTIVE', 'INACTIVE'].includes(status.toUpperCase())) {
      media.status = status.toUpperCase();
    }

    if (tags !== undefined) {
      media.tags = typeof tags === 'string'
        ? tags.split(',').map((t) => t.trim()).filter(Boolean)
        : Array.isArray(tags) ? tags : media.tags;
    }

    if (Array.isArray(usedIn)) {
      media.usedIn = usedIn;
    }

    media.updatedBy = req.user?._id;
    await media.save();

    // Trigger cross-collection image synchronization
    await syncMediaImageToCollections(media, oldUrl);

    res.json({
      success: true,
      message: req.file ? 'Media asset image and metadata updated successfully' : 'Media metadata updated successfully',
      data: media,
    });
  } catch (err) {
    console.error('[Update Media Error]:', err.message);
    res.status(500).json({ success: false, message: err.message || 'Failed to update media item' });
  }
};

// @desc    Replace underlying image file
// @route   PUT /api/media/:id/replace
// @access  Private/Admin
export const replaceMediaFile = async (req, res) => {
  try {
    const media = await Media.findById(req.params.id);
    if (!media) {
      return res.status(404).json({
        success: false,
        message: 'Media asset not found',
        errorCode: 'MEDIA_NOT_FOUND',
      });
    }

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No new image file uploaded for replacement',
        errorCode: 'FILE_MISSING',
      });
    }

    const oldUrl = media.url;
    const oldPublicId = media.publicId;
    const folder = `chinmaya/media/${media.category.toLowerCase().replace(/\s+/g, '_')}`;
    const result = await uploadToR2(req.file.buffer, folder, req.file.mimetype, req.file.originalname);

    // Delete old R2 object (non-blocking)
    if (oldPublicId) deleteFromR2(oldPublicId).catch(() => {});

    media.url = result.url;
    media.thumbnailUrl = result.url;
    media.publicId = result.public_id;
    media.mimeType = req.file.mimetype;
    media.fileSize = req.file.size || req.file.buffer.length;
    media.originalFileName = req.file.originalname || media.originalFileName;
    media.updatedBy = req.user?._id;

    await media.save();

    // Trigger cross-collection image synchronization
    await syncMediaImageToCollections(media, oldUrl);

    res.json({
      success: true,
      message: 'Image asset replaced successfully',
      data: media,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc    Delete media asset
// @route   DELETE /api/media/:id
// @access  Private/Admin
export const deleteMedia = async (req, res) => {
  try {
    const { force } = req.query;
    const media = await Media.findById(req.params.id);
    if (!media) {
      return res.status(404).json({
        success: false,
        message: 'Media asset not found',
        errorCode: 'MEDIA_NOT_FOUND',
      });
    }

    // Safety check if image is currently used in CMS sections
    if (media.usedIn && media.usedIn.length > 0 && force !== 'true') {
      const locations = media.usedIn.map((u) => `${u.page} → ${u.section}`).join(', ');
      return res.status(400).json({
        success: false,
        requiresConfirmation: true,
        message: `This image is currently referenced in: ${locations}. Are you sure you want to delete it?`,
        usedIn: media.usedIn,
      });
    }

    const mediaUrl = media.url;
    const mediaTitle = media.title;
    const mediaPublicId = media.publicId;

    // 1. Permanently delete matching activities
    if (mediaUrl || mediaPublicId || mediaTitle) {
      const actFilter = [];
      if (mediaPublicId) actFilter.push({ publicId: mediaPublicId });
      if (mediaUrl) actFilter.push({ imageUrl: mediaUrl });
      if (mediaTitle) actFilter.push({ title: mediaTitle });
      if (actFilter.length > 0) {
        await Activity.deleteMany({ $or: actFilter });
      }
    }

    // 2. Permanently delete matching banners
    if (mediaUrl || mediaPublicId || mediaTitle) {
      const banFilter = [];
      if (mediaPublicId) banFilter.push({ publicId: mediaPublicId });
      if (mediaUrl) banFilter.push({ imageUrl: mediaUrl });
      if (mediaTitle) banFilter.push({ title: mediaTitle });
      if (banFilter.length > 0) {
        await Banner.deleteMany({ $or: banFilter });
      }
    }

    // 3. Clear from HomePage sections if referenced
    const homeConfig = await HomePage.findOne();
    if (homeConfig) {
      let homeChanged = false;
      if (homeConfig.disabledImage === mediaUrl) {
        homeConfig.disabledImage = '';
        homeChanged = true;
      }
      if (Array.isArray(homeConfig.sections)) {
        homeConfig.sections.forEach((sec) => {
          if (sec.imageUrl === mediaUrl) {
            sec.imageUrl = '';
            homeChanged = true;
          }
        });
      }
      if (homeChanged) await homeConfig.save();
    }

    // 4. Clear from PageContent if referenced
    const allPageContents = await PageContent.find();
    for (const pc of allPageContents) {
      let pcChanged = false;
      const targetObj = pc.content || pc.data;
      if (targetObj && mediaUrl) {
        const jsonStr = JSON.stringify(targetObj);
        if (jsonStr.includes(mediaUrl)) {
          const replacedStr = jsonStr.replaceAll(mediaUrl, '');
          if (pc.content) pc.content = JSON.parse(replacedStr);
          else if (pc.data) pc.data = JSON.parse(replacedStr);
          pcChanged = true;
        }
      }
      if (pcChanged) await pc.save();
    }

    await Media.findByIdAndDelete(req.params.id);

    // Delete from Cloudflare R2
    if (mediaPublicId) {
      await deleteFromR2(mediaPublicId);
    }

    res.json({
      success: true,
      message: 'Media asset deleted permanently from all pages and website sections',
      data: { id: req.params.id },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// @desc    Get categories & page list for filters
// @route   GET /api/media/categories
// @access  Private/Admin
export const getMediaCategories = async (req, res) => {
  try {
    const categories = ['Home', 'About', 'Activities', 'Let\'s Connect', 'Marathon', 'Registration', 'Banner', 'Footer', 'Gallery', 'Other'];
    const pages = ['Home', 'About', 'Activities', 'Let\'s Connect', 'Registration', 'General'];
    
    res.json({
      success: true,
      data: { categories, pages },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
