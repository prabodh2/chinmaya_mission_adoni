import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, Outlet } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { SiteSettingsProvider } from './context/SiteSettingsContext';
import { SiteAccessGate } from './components/SiteAccessGate';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ProtectedRoute } from './components/auth/ProtectedRoute';

// Public Website Pages
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ChinmayaMissionAdoniPage } from './pages/ChinmayaMissionAdoniPage';
import { ActivitiesPage } from './pages/ActivitiesPage';
import { WhoAreWePage } from './pages/WhoAreWePage';
import { LetsConnectPage } from './pages/LetsConnectPage';
import { RegistrationPage } from './pages/RegistrationPage';
import { ChinmayaSanjeevarayaTemplePage } from './pages/ChinmayaSanjeevarayaTemplePage';
import { SriShanthaMamleshwaraSwamiTemplePage } from './pages/SriShanthaMamleshwaraSwamiTemplePage';
import { GalleryPage } from './pages/GalleryPage';
import { SupportOurMissionPage } from './pages/SupportOurMissionPage';
import { ComingSoonPage } from './pages/ComingSoonPage';

// Public Authentication Pages
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';

// User Account Pages (Protected)
import { ProfilePage } from './pages/ProfilePage';
import { MyActivityPage } from './pages/MyActivityPage';

// Admin Pages (Standalone Layout & Isolated Authentication)
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';

const MARATHON_PORTAL_URL =
  import.meta.env.VITE_MARATHON_URL || 'https://marathon-chinmaya-mission-adoni.vercel.app/';

function MarathonPortalRedirect({ path = '' }) {
  useEffect(() => {
    window.location.href = `${MARATHON_PORTAL_URL}${path}`;
  }, [path]);

  return (
    <div className="min-h-[50vh] flex flex-col items-center justify-center p-6 text-center">
      <div className="w-10 h-10 border-4 border-[var(--orange)] border-t-transparent rounded-full animate-spin mb-4" />
      <p className="text-sm font-bold text-[var(--text-primary)]">
        Redirecting to Anti-Drug Marathon Run 2026 Portal...
      </p>
      <a
        href={`${MARATHON_PORTAL_URL}${path}`}
        className="mt-3 text-xs font-bold text-[var(--orange)] underline"
      >
        Click here if not redirected automatically
      </a>
    </div>
  );
}

// Public Layout containing Public Navbar and Footer
function PublicLayout() {
  return (
    <div className="min-h-screen flex flex-col justify-between selection:bg-[var(--orange)] selection:text-white w-full max-w-full overflow-x-hidden bg-white">
      <Navbar />
      <main className="flex-grow pt-16 md:pt-20 w-full max-w-full overflow-x-hidden">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

// Scroll to top helper on route change
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'instant',
    });
  }, [pathname]);

  return null;
}

export function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <SiteSettingsProvider>
          <Router>
            <ScrollToTop />
            <SiteAccessGate>
              <Routes>
            {/* 1. Main Chinmaya Mission Website Pages */}
            <Route element={<PublicLayout />}>
              {/* Main Landing Page */}
              <Route path="/" element={<HomePage />} />
              <Route path="/chinmaya-mission-adoni" element={<ChinmayaMissionAdoniPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/about-us" element={<AboutPage />} />
              <Route path="/aboutus" element={<AboutPage />} />
              <Route path="/about-me" element={<AboutPage />} />
              <Route path="/events" element={<ActivitiesPage />} />
              <Route path="/activities" element={<ActivitiesPage />} />
              <Route path="/who-are-we" element={<WhoAreWePage />} />
              <Route path="/who-we-are" element={<WhoAreWePage />} />
              <Route path="/whoarewe" element={<WhoAreWePage />} />
              <Route path="/lets-connect" element={<LetsConnectPage />} />
              <Route path="/support-our-mission" element={<SupportOurMissionPage />} />
              <Route path="/support-mission" element={<SupportOurMissionPage />} />
              <Route path="/supportourmission" element={<SupportOurMissionPage />} />
              
              {/* Dedicated Temple & Centre Pages */}
              <Route path="/chinmaya-sanjeevaraya-temple" element={<ChinmayaSanjeevarayaTemplePage />} />
              <Route path="/chinmaya-sanjeevaraya" element={<ChinmayaSanjeevarayaTemplePage />} />
              <Route path="/sanjeevaraya-temple" element={<ChinmayaSanjeevarayaTemplePage />} />
              <Route path="/sri-shantha-mamleshwara-swami-temple" element={<SriShanthaMamleshwaraSwamiTemplePage />} />
              <Route path="/shri-shantamalleshwara-swami-temple" element={<SriShanthaMamleshwaraSwamiTemplePage />} />
              <Route path="/shantamalleshwara-temple" element={<SriShanthaMamleshwaraSwamiTemplePage />} />
              <Route path="/shanta-malleshwara-temple" element={<SriShanthaMamleshwaraSwamiTemplePage />} />
              
              {/* Sacred Image Gallery Page */}
              <Route path="/gallery" element={<GalleryPage />} />
              <Route path="/images" element={<GalleryPage />} />
              <Route path="/image" element={<GalleryPage />} />
              <Route path="/sacred-gallery" element={<GalleryPage />} />
              
              {/* Authentication & User Account Routes */}
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/account"
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-account"
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-profile"
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-bookings"
                element={
                  <ProtectedRoute>
                    <ProfilePage initialTab="bookings" />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-seva-bookings"
                element={
                  <ProtectedRoute>
                    <ProfilePage initialTab="bookings" />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-activity"
                element={
                  <ProtectedRoute>
                    <MyActivityPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-registrations"
                element={
                  <ProtectedRoute>
                    <MyActivityPage />
                  </ProtectedRoute>
                }
              />

              {/* Marathon portal redirects (marathon is hosted separately) */}
              <Route path="/register" element={<MarathonPortalRedirect path="/register" />} />
              <Route path="/your-thoughts" element={<MarathonPortalRedirect path="/your-thoughts" />} />
              <Route path="/story-board" element={<MarathonPortalRedirect path="/your-thoughts" />} />
              <Route path="/storyboard" element={<MarathonPortalRedirect path="/your-thoughts" />} />
            </Route>

            {/* Standalone Teaser / Coming Soon Page */}
            <Route path="/coming-soon" element={<ComingSoonPage />} />
            <Route path="/comming-soon" element={<ComingSoonPage />} />
            <Route path="/launch" element={<ComingSoonPage />} />
            <Route path="/teaser" element={<ComingSoonPage />} />

            {/* 2. Standalone Admin Login (NO Public Navbar, NO Public Footer, NO Normal User Pill) */}
            <Route path="/admin/login" element={<AdminLoginPage />} />

            {/* 3. Standalone Admin Control Panel (Strict RBAC, Dedicated Admin Navigation) */}
            <Route
              path="/admin"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="STATS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/dashboard"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="STATS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/story-board"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="STORY_BOARD" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/storyboard"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="STORY_BOARD" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/users"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="USERS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/profile"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="ADMIN_PROFILE" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/registrations"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="REGISTRATIONS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/event-config"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="EVENT_CONFIG" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/images"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="IMAGES" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/home"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="HOME_PAGE" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/about"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="ABOUT_CMS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/activities"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="ACTIVITIES" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/banners"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="BANNERS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/lets-connect"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="LETS_CONNECT" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/volunteering"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="VOLUNTEERING" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/bookings"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="BOOKINGS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/seva-bookings"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="BOOKINGS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/donations"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="BOOKINGS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/footer"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="FOOTER_CMS" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/update-content"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="UPDATE_CONTENT" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/content"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="UPDATE_CONTENT" />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/change-password"
              element={
                <ProtectedRoute requireAdmin={true}>
                  <AdminDashboardPage defaultTab="PASSWORD" />
                </ProtectedRoute>
              }
            />

            {/* Catch-all Redirect */}
            <Route path="*" element={<Navigate to="/chinmaya-mission-adoni" replace />} />
          </Routes>
        </SiteAccessGate>
      </Router>
    </SiteSettingsProvider>
  </AuthProvider>
</ThemeProvider>
  );
}

export default App;
